package com.company.service;

import com.company.dto.SignupForm;
import org.springframework.stereotype.Service;

@Service
public class UserService {

    public void saveUser(SignupForm signupForm) {
        // 사용자 정보를 데이터베이스에 저장 구현
    }
    public boolean authenticateUser(String username, String password) {
            // 실제 인증 로직 구현
            // 예시로 하드코딩된 인증 체크
         return "admin".equals(username) && "password".equals(password);
    }
}
