import React from 'react';

const Storage = React.createContext();

export default Storage;