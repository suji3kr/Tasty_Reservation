# Change Log 

> All notable changes to this project will be documented in this file.

<br>

<br/>

## [0.0.2] - 4/20/2020

### Changed

- Update store list

<br>

## [0.0.2] - 4/15/2020

### Changed

- Update login component
  -  Separate admin login
- Update entrance component
  - Modify phrases

<br>

## [0.0.1] - 2/22/2020

### Changed

- Update back > src > main > resources> mapper > Mapper.xml