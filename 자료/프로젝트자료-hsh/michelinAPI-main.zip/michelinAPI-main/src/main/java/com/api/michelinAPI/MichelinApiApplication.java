package com.api.michelinAPI;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class MichelinApiApplication {

	public static void main(String[] args) {
		SpringApplication.run(MichelinApiApplication.class, args);
	}

}
