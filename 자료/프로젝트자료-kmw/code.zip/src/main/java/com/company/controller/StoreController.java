package com.company.controller;

import java.io.File;
import java.io.IOException;
import java.util.List;
import javax.servlet.http.HttpServletRequest;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.multipart.MultipartFile;

import com.company.domain.StoreDTO;
import com.company.service.StoreService;

@Controller
@RequestMapping("/store")
public class StoreController {

    @Autowired
    private StoreService storeService;

    // 가게 등록 폼 페이지
    @GetMapping("/register")
    public String showRegisterForm() {
        return "store/register";  // 올바른 JSP 파일 경로 사용
    }

    // 가게 등록 처리
    @PostMapping("/register")
    public String registerStore(@ModelAttribute StoreDTO storeDTO,
                                @RequestParam(value = "storeImage", required = false) MultipartFile storeImage,
                                HttpServletRequest request) throws IOException {
        System.out.println("Received storeName: " + storeDTO.getStoreName());  // 디버깅용 로그

        // 파일 업로드 처리
        String uploadDir = request.getServletContext().getRealPath("/uploads/");
        File dir = new File(uploadDir);
        if (!dir.exists()) {
            dir.mkdirs();
        }

        String fileName = storeImage.getOriginalFilename();
        if (fileName != null && !fileName.isEmpty()) {
            File uploadFile = new File(uploadDir, fileName);
            storeImage.transferTo(uploadFile);
            storeDTO.setStoreImage("/uploads/" + fileName);
        } else {
            storeDTO.setStoreImage("default.jpg");
        }

        // 서비스 호출
        storeService.registerStore(storeDTO);

        return "redirect:/store/storelist";
    }


    // 가게 목록 조회
    @GetMapping("/storelist")
    public String listStores(Model model) {
        List<StoreDTO> stores = storeService.getAllStores();
        model.addAttribute("stores", stores);
        return "store/storelist";  // JSP 경로 수정 (store 폴더 안의 storelist.jsp로 연결)
    }
}
